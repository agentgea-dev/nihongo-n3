// loader.js — SAKURA ANKI N3 — v4
// Update: grammar 100% ✅ | kanji 100% ✅
window.addKanji   = e => { if(!window.KANJI_DB)  window.KANJI_DB=[];  window.KANJI_DB.push(...e);  };
window.addGrammar = e => { if(!window.GRAMMAR_DB) window.GRAMMAR_DB=[]; window.GRAMMAR_DB.push(...e); };
window.addVocab   = e => { if(!window.VOCAB_DB)  window.VOCAB_DB=[];  window.VOCAB_DB.push(...e);  };

window.__DB_READY = false;
window.addEventListener('DOMContentLoaded', () => {
  const k = window.KANJI_DB?.length   || 0;
  const g = window.GRAMMAR_DB?.length || 0;
  const v = window.VOCAB_DB?.length   || 0;
  window.__DB_READY = true;
  console.log(`🌸 DB AKTIF | Kanji:${k}/650 Grammar:${g}/168 Vocab:${v}/3750 Total:${k+g+v}`);
  window.dispatchEvent(new CustomEvent('db-ready', { detail:{kanji:k,grammar:g,vocab:v} }));
});

// FILE TERDAFTAR:
// KANJI  : kanji, kanji-alam,
//           kanji-batch1-kerja, kanji-batch2-kesehatan, kanji-batch3-pendidikan,
//           kanji-batch4-sosial, kanji-batch5-waktu, kanji-batch6-pikiran,
//           kanji-batch7-makanan, kanji-batch8-final          ← 650/650 ✅
// GRAMMAR: grammar, grammar-batch1, grammar-batch2, grammar-batch3, grammar-final  ← 168/168 ✅
// VOCAB  : vocabulary, vocab-kerja,
//           vocab-batch1-sifat, vocab-batch2-katakerja,
//           vocab-batch3-kehidupan, vocab-batch4-alam-teknologi   ← 339/3750
